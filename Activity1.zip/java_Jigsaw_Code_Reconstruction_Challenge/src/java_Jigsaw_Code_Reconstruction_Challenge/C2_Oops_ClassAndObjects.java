package java_Jigsaw_Code_Reconstruction_Challenge;

//Fix the code so it correctly assigns and prints the model name.

class Car {
    String model;
}

public class C2_Oops_ClassAndObjects {
    public static void main(String[] args) {
    	Car c;
        c.model = "Honda";
        System.out.println(c.model);
    }
}
