package java_Jigsaw_Code_Reconstruction_Challenge;

//This code is meant to print numbers from 1 to 5

public class C3_LoopAndDataType {
	
	public static void main(String[] args) {

		for (int i = 1; i < 5; i++) {

			System.out.println(i)

		}

	}

}
