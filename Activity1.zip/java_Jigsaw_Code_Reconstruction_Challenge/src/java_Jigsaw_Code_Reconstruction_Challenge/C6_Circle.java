package java_Jigsaw_Code_Reconstruction_Challenge;

// Reconstruct a Circle class that has a final static PI variable and a static method to calculate the area.

public class C6_Circle {

    public final double PI = 3.14159;

    public double calculateArea(double radius) {
        return PI * radius * radius;
    }

    public static void main(String[] args) {

        double area = calculateArea(10);
        System.out.println("The area of the circle is: " + area);
    }
}